"""Train ML models for AIMI-CARE (currently diabetes risk) and save to disk."""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import joblib

URL = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/pima-indians-diabetes.data.csv"
COLUMNS = [
    "Pregnancies",
    "Glucose",
    "BloodPressure",
    "SkinThickness",
    "Insulin",
    "BMI",
    "DiabetesPedigreeFunction",
    "Age",
    "Outcome",
]

print("\n⏳  Downloading dataset …")
df = pd.read_csv(URL, names=COLUMNS)

# Replace zeroes in physiological columns with NaN and impute with column mean
cols_with_nan = [
    "Glucose",
    "BloodPressure",
    "SkinThickness",
    "Insulin",
    "BMI",
]
df[cols_with_nan] = df[cols_with_nan].replace(0, pd.NA)
df.fillna(df.mean(numeric_only=True), inplace=True)

X = df.drop("Outcome", axis=1)
y = df["Outcome"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = LogisticRegression(max_iter=1000)
print("🚀  Training LogisticRegression model …")
model.fit(X_train, y_train)

preds = model.predict(X_test)
acc = accuracy_score(y_test, preds)
print(f"📊  Test accuracy: {acc:.3f}\n")
print(classification_report(y_test, preds))

MODEL_PATH = "diabetes_model.joblib"
joblib.dump(model, MODEL_PATH)
print(f"✅  Saved trained model to {MODEL_PATH}\n")
