"""Utility helpers to load ML models and make predictions."""

import joblib
from pathlib import Path
import numpy as np

MODEL_PATH = Path(__file__).resolve().parent.parent / "diabetes_model.joblib"
_diabetes_model = None


def _load_diabetes_model():
    global _diabetes_model
    if _diabetes_model is None:
        if not MODEL_PATH.exists():
            raise FileNotFoundError(
                f"Model file not found at {MODEL_PATH}. Run scripts/train_models.py first."
            )
        _diabetes_model = joblib.load(MODEL_PATH)
    return _diabetes_model


def predict_diabetes(features: list[float]) -> int:
    """Return 1 if diabetic, else 0.

    Expected order of features:
        [Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI,
         DiabetesPedigreeFunction, Age]
    """

    model = _load_diabetes_model()
    X = np.array(features).reshape(1, -1)
    return int(model.predict(X)[0])
