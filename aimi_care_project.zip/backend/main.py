"""FastAPI application exposing prediction endpoints."""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

from .database import SessionLocal, init_db, VitalRecord
from .model_utils import predict_diabetes

app = FastAPI(
    title="AIMI-CARE Health API",
    description="Predict early disease risk from user vitals.",
    version="1.0.0",
)


class VitalRequest(BaseModel):
    user_id: str = Field(..., example="user123")
    pregnancies: int = Field(..., ge=0, example=2)
    glucose: float = Field(..., ge=0, example=120)
    blood_pressure: float = Field(..., ge=0, example=80)
    skin_thickness: float = Field(..., ge=0, example=25)
    insulin: float = Field(..., ge=0, example=80)
    bmi: float = Field(..., ge=0, example=24.5)
    diabetes_pedigree: float = Field(..., ge=0, example=0.5)
    age: int = Field(..., ge=0, example=35)


class PredictionResponse(BaseModel):
    diabetes_risk: int
    created_at: datetime


init_db()


@app.post("/predict", response_model=PredictionResponse)
def predict(req: VitalRequest):
    features = [
        req.pregnancies,
        req.glucose,
        req.blood_pressure,
        req.skin_thickness,
        req.insulin,
        req.bmi,
        req.diabetes_pedigree,
        req.age,
    ]

    try:
        risk = predict_diabetes(features)
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e))

    # Persist to DB
    db = SessionLocal()
    record = VitalRecord(
        user_id=req.user_id,
        heart_rate=None,  # Not used in this demo model
        systolic_bp=req.blood_pressure,  # mapping for demo
        diastolic_bp=None,
        glucose=req.glucose,
        bmi=req.bmi,
        age=req.age,
        label_diabetes=risk,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    db.close()

    return PredictionResponse(diabetes_risk=risk, created_at=record.timestamp)
