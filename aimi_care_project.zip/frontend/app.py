"""Streamlit UI that collects user vitals and calls the FastAPI backend."""

import streamlit as st
import requests

API_URL = "http://localhost:8000/predict"

st.set_page_config(page_title="AIMI-CARE Dashboard", layout="centered")
st.title("🩺 AIMI-CARE — Health Monitoring & Early Disease Prediction")
st.write("Fill in your latest vitals to get an instant diabetes-risk assessment.")

with st.form("vitals_form"):
    user_id = st.text_input("User ID", "demo_user")
    pregnancies = st.number_input("Pregnancies", 0, 20, 2)
    glucose = st.slider("Glucose (mg/dL)", 50, 300, 120)
    blood_pressure = st.slider("Blood Pressure (mmHg)", 40, 200, 80)
    skin_thickness = st.slider("Skin Thickness (mm)", 0, 99, 23)
    insulin = st.slider("Insulin (IU/mL)", 0, 846, 79)
    bmi = st.slider("Body-Mass Index (BMI)", 10.0, 50.0, 25.3)
    diabetes_pedigree = st.slider("Diabetes Pedigree Function", 0.000, 2.500, 0.5)
    age = st.number_input("Age (years)", 1, 120, 35)

    submitted = st.form_submit_button("Predict Risk")

if submitted:
    payload = {
        "user_id": user_id,
        "pregnancies": pregnancies,
        "glucose": glucose,
        "blood_pressure": blood_pressure,
        "skin_thickness": skin_thickness,
        "insulin": insulin,
        "bmi": bmi,
        "diabetes_pedigree": diabetes_pedigree,
        "age": age,
    }
    with st.spinner("Fetching prediction …"):
        try:
            rsp = requests.post(API_URL, json=payload, timeout=10)
            rsp.raise_for_status()
            result = rsp.json()
            is_positive = result["diabetes_risk"] == 1
            st.success(
                f"### Result: {'🚨 High' if is_positive else '✅ Low'} risk for Diabetes"
            )
            st.write(f"Prediction timestamp: {result['created_at']}")
        except requests.RequestException as err:
            st.error(f"API error: {err}")
