# AIMI-CARE — Major Project

## Quick-Start (local)

```bash
# 1️⃣  Clone / copy this repo
cd aimi_care                     # adjust path if needed
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt  # install dependencies

# 3️⃣  Train ML model(s)
python scripts/train_models.py    # creates diabetes_model.joblib

# 4️⃣  Launch the backend API
uvicorn backend.main:app --reload --port 8000

# 5️⃣  Start the Streamlit dashboard
streamlit run frontend/app.py
```

Navigate to <http://localhost:8501> and try out the app! 🎉

## Extending the Project
* **Add more diseases** — train separate models and expose new endpoints.
* **Replace SQLite** with Postgres or TimescaleDB for scalability.
* **Real sensor ingestion** — integrate with wearable APIs or MQTT brokers.
* **Authentication** — secure endpoints with OAuth/JWT.
* **Dockerization & CI/CD** — containerize services and deploy to cloud.
